package com.excelread.test;

public class Employee {
	String empid;
	String empName;
	String empDate;
	long empWorkHours;
	
	public long getEmpWorkHours() {
		return empWorkHours;
	}
	public void setEmpWorkHours(long empWorkHours) {
		this.empWorkHours = empWorkHours;
	}
	public String getEmpDate() {
		return empDate;
	}
	public void setEmpDate(String empDate) {
		this.empDate = empDate;
	}
	String empCheckIn;
	String empCheckOut;
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCheckIn() {
		return empCheckIn;
	}
	public void setEmpCheckIn(String empCheckIn) {
		this.empCheckIn = empCheckIn;
	}
	public String getEmpCheckOut() {
		return empCheckOut;
	}
	public void setEmpCheckOut(String empCheckOut) {
		this.empCheckOut = empCheckOut;
	}
	
	
	
	
}